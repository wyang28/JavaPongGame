package Pongy;

/**William Yang APCS Period 5
*I William Yang acknowledge that this is my own independent work
*and conforms to Oxford Academy's Academic Honesty Guidelines.
*
*I looked up some videos of animation and mouse events. 
*Everything else was coded by me 
*(including collision detection)
*/
import javax.swing.*;
import java.awt.Color;
import java.awt.Graphics;
public class FinalProjectMain {
    
     public static void main (String[] args){
    	 JFrame title = new JFrame("Harder Pong");
    	 title.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	 BouncingBall b = new BouncingBall();
    	 title.add(b);
    	 title.setSize(400,500); //x and y
    	 title.setVisible(true);
    	 title.setBackground(Color.WHITE);
    	 title.setResizable(false);
    	 title.setLocationRelativeTo(null);
     }
}
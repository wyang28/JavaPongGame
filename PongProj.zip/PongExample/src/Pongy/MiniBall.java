package Pongy;


public class MiniBall {
    private int x = 25, y = 25, xLoc, yLoc, velX = -1, velY = 2;
    public MiniBall( int xa, int ya){
        xLoc = xa;
        yLoc = ya;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }

    public int getXLoc(){
        return xLoc;
    }

    public int getYLoc(){
        return yLoc;
    }

    public int getVelocityX(){
        return velX;
    }

    public int getVelocityY(){
        return velY;
    }

    public void setX(int X){
        x = X;
    }

    public void setY(int Y){
        y = Y;
    }

    public void setXLoc(int XA){
        xLoc = XA;
    }

    public void setYLoc(int YA){
        yLoc = YA;
    }

    public void setVelX(int x){
        velX = x;
    }

    public void setVelY(int y){
        velY = y;
    }

}

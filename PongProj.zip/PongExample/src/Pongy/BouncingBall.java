package Pongy;

import java.awt.Font;
import java.awt.event.*;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import javax.swing.Timer;
import javax.swing.JPanel;
import java.util.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
public class BouncingBall extends JPanel implements ActionListener, KeyListener{
    private int velX = -1, velY = -1;
    private int bounceCount;
    private int rX = 0, rY = 0;
    private int x = 16, y = 4;
    private Stack<MiniBall> ball = new Stack<MiniBall>();
    private Timer t;
    private int x2 = 100, y2 = 400; 
    private boolean leftOrRight = false, activated = false;
    private MiniBall coords;
    private MiniBall coords2;
    private JLabel scoreLabel;

    //sets up timer(action) thread and mouse events
    public BouncingBall(){
        ball.push(new MiniBall(100,50));
        coords = ball.peek();
        ball.push(new MiniBall(10, 0));
        coords2 = ball.peek();
        coords2.setXLoc(250);
        coords2.setYLoc(50);
        coords2.setVelX(coords2.getVelocityY());
        coords2.setVelY(-1);
        bounceCount = 0;
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        scoreLabel = new JLabel(Integer.toString(bounceCount));
        scoreLabel.setFont(new Font("ROMAN_BASELINE", Font.BOLD, 50));
        add(scoreLabel);
        t = new Timer(14, this);
        t.start();

    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawString("Level: " + "", 0, 0);
        g.setColor(Color.MAGENTA);
        g.fillOval(x, y, 50, 50);
        g.setColor(Color.cyan);
        g.fillRect(x2,y2,70,20);
        if(!ball.isEmpty() ){ //adds circles from the stack
            g.setColor(Color.ORANGE);
            g.fillOval(coords.getXLoc(), coords.getYLoc(), coords.getX(), coords.getY());
        }
        if(!ball.isEmpty() ){
            g.setColor(new Color(0,255,0));
            g.fillOval(coords2.getXLoc(), coords2.getYLoc(), coords.getY(), coords.getX());
        }

    }

    //checks if circle touches rectangle
    public boolean bounceOnRect(){
        if(y == 350 && ((x > x2-70 && x < x2+70))){				
            return true;	
        }else{
            return false;
        }
    }

    //checks if mini circle touches against rectangle
    public boolean lilBallAgainstRect(MiniBall ball){
        if(ball.getYLoc() == 378 && (ball.getXLoc() > x2 - 70 && ball.getXLoc() < x2 + 70)){
            return true;
        }
        return false;
    }   

    public void actionPerformed(ActionEvent e){ 

        //checks collision detection on paddle
        if(bounceOnRect() && leftOrRight == false){
            velY = -velY;
            scoreLabel.setText(Integer.toString(bounceCount));
            activated = true;
        }else if(bounceOnRect() && leftOrRight == true){
            velX = -velX;	  
            velY = -velY;
            scoreLabel.setText(Integer.toString(bounceCount));

        }else{
            if(x < 0 || x > 335){
                velX = -velX;  
            }
            if(y < 0 ){
                velY = -velY;
            }	 
            if(y > 500 || (activated == true && coords.getYLoc() > 500) || 
            (activated == true && coords2.getYLoc() > 500)){
                t.stop();
                JOptionPane.showMessageDialog(null,"Game Over. This is your score: " + bounceCount, "One Ball Fell Below the Paddle: ", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        //checks miniball collision detection
        if(activated == true && lilBallAgainstRect(coords) && leftOrRight == false){
            coords.setVelY(-coords.getVelocityY());
            bounceCount++;
            scoreLabel.setText(Integer.toString(bounceCount));
        }else if(activated == true && lilBallAgainstRect(coords) && leftOrRight == true){
            coords.setVelX(-coords.getVelocityX());
            coords.setVelY(-coords.getVelocityY());
            bounceCount++;
            scoreLabel.setText(Integer.toString(bounceCount));
        }else{
            if(coords.getXLoc() < 0 || coords.getXLoc() > 370){
                coords.setVelX(-coords.getVelocityX());
            }
            if(coords.getYLoc() < 0){
                coords.setVelY(-coords.getVelocityY());
            }
        }
        //checks collision of second miniball (yes it's not efficient)
        if(activated == true && bounceCount > 9 && lilBallAgainstRect(coords2) && leftOrRight == false){
            coords2.setVelY(-coords2.getVelocityY());
            bounceCount++;
            scoreLabel.setText(Integer.toString(bounceCount));
        }else if(activated == true && lilBallAgainstRect(coords2) && leftOrRight == true){
            coords2.setVelX(-coords2.getVelocityX());
            coords2.setVelY(-coords2.getVelocityY());
            bounceCount++;
            scoreLabel.setText(Integer.toString(bounceCount));
        }else{
            if(coords2.getXLoc() < 0 || coords2.getXLoc() > 350){
                coords2.setVelX(-coords2.getVelocityX());
            }
            if(coords2.getYLoc() < 0){
                coords2.setVelY(-coords2.getVelocityY());
            }
        }
        //check if rectangle is out of screen 
        if(x2 < 0){
            x2 = 0;
        }else if(x2 > 330){
            x2 = 330;
        }else{
            x2 += rX;
        }
        //shift position by velocities
        x = x + velX;
        y = y + velY;
        if( activated == true ){
            coords.setXLoc(coords.getXLoc() + coords.getVelocityX());
            coords.setYLoc(coords.getYLoc() + coords.getVelocityY());
            if(activated && bounceCount > 9){
                coords2.setXLoc(coords2.getXLoc() + coords2.getVelocityX());
                coords2.setYLoc(coords2.getYLoc() + coords2.getVelocityY());
            }
        }
        repaint();
    }

    //moves rectangle
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if(key == KeyEvent.VK_LEFT){
            rX = -6;
            leftOrRight = false;
        }
        if(key == KeyEvent.VK_RIGHT){
            rX = 6;
            leftOrRight = true;
        }
    }  

    //stops rectangle when arrow not pressed
    public void keyReleased(KeyEvent e) {
        rX = 0;
        rY = 0;
    }

    //no purpose
    public void keyTyped(KeyEvent e) {

    }

}

